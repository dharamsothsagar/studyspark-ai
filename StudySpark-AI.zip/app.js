const $=id=>document.getElementById(id);
const demo={
 explanation:t=>`<p><b>${t}</b> is a topic you can break into a few key ideas. Start by defining the main concept, then connect it to examples and finally test yourself without looking at your notes.</p><p><b>Study method:</b> learn one small idea, explain it in your own words, and answer a question about it from memory.</p>`,
 summary:t=>`<ul><li>Define the main idea of ${t}.</li><li>Learn 3–5 important terms.</li><li>Connect each term to an example.</li><li>Test yourself and review mistakes.</li></ul>`,
 quiz:t=>[`What is the main idea of ${t}?`,`Name two important terms related to ${t}.`,`Give one real-world example of ${t}.`,`What is a common mistake students make when learning ${t}?`],
 cards:t=>[`What is ${t}?`,`What are the key ideas in ${t}?`,`Why is ${t} important?`,`Give an example related to ${t}.`]
};
function generate(){
 const t=$('topic').value.trim()||'your topic';
 $('output').classList.remove('hidden');
 $('explanation').innerHTML=demo.explanation(t);
 $('summary').innerHTML=demo.summary(t);
 $('quiz').innerHTML=demo.quiz(t).map((q,i)=>`<div class="answer"><b>${i+1}.</b> ${q}<br><button onclick="this.nextElementSibling.classList.toggle('hidden')">Show sample approach</button><span class="hidden"> Start with the definition, then give a concise example.</span></div>`).join('');
 $('cards').innerHTML=demo.cards(t).map((q,i)=>`<div class="flash"><b>Q: ${q}</b><span class="hidden">A: Explain it in your own words, then check your notes.</span><button onclick="this.previousElementSibling.classList.toggle('hidden')">Reveal</button></div>`).join('');
}
$('generate').onclick=generate;
$('themeBtn').onclick=()=>document.body.classList.toggle('dark');
$('topic').addEventListener('keydown',e=>{if(e.key==='Enter')generate()});
# StudySpark AI

A simple AI Study Helper prototype.

## Run it
Open `index.html` in a browser.

## Important
This version uses local demo generation so it works without an API key. To make it genuinely AI-powered, add a small server backend and call an AI API from the server. Never put an API key directly in `app.js` or other browser code.

## Monetization ideas
- Free: limited study packs
- Premium: more generations, saved study packs, progress tracking
- School/teacher plan: class study packs and quizzes
